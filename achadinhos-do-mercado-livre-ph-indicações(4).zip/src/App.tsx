import React, { useState, useMemo, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ProductCard } from './components/ProductCard';
import { StatsDashboard } from './components/StatsDashboard';
import { LoginModal } from './components/LoginModal';
import { ConfirmModal } from './components/ConfirmModal';
import { CATEGORIES } from './constants';
import { Product, Category } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { blockchain } from './services/blockchain';
import { ShoppingBag, Star, Zap, Bell, Plus, X, Link as LinkIcon, Tag, Image as ImageIcon, Info, Sparkles, Wand2, AlertCircle, Pencil, Upload, Settings, ShieldCheck, Wallet, BarChart3, ArrowUpRight, Mail, Heart, Share2, ClipboardList, Check } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  deleteDoc, 
  doc, 
  updateDoc, 
  setDoc,
  query, 
  orderBy, 
  serverTimestamp,
  getDocFromServer
} from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { db, auth } from './firebase';
import firebaseConfig from '../firebase-applet-config.json';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category>('Todos');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });
  const [importText, setImportText] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);
  
  // Form State
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    platform: 'Mercado Livre',
    category: 'Eletrônicos',
    clickCount: 0
  });

  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [dynamicAiKey, setDynamicAiKey] = useState<string | null>(() => {
    const key = import.meta.env.VITE_GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY" && !key.startsWith("TODO")) {
      return key;
    }
    return null;
  });
  const [localAiKey, setLocalAiKey] = useState<string>(localStorage.getItem('gemini_api_key') || '');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const [isTestingKey, setIsTestingKey] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isVerifyingBlockchain, setIsVerifyingBlockchain] = useState(false);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('product_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('product_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  const toggleWishlist = (productId: string) => {
    setWishlist(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId) 
        : [...prev, productId]
    );
    const isAdding = !wishlist.includes(productId);
    setToast({ 
      message: isAdding ? "Adicionado à sua lista!" : "Removido da sua lista.", 
      type: 'success' 
    });
  };

  const shareProduct = async (product: Product) => {
    const shareData = {
      title: `Confira este Achadinho: ${product.title}`,
      text: `Vi este produto no Achadinhos e achei incrível! Preço: R$ ${product.price.toLocaleString('pt-BR')}`,
      url: window.location.href + '#product-' + product.id
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
        setToast({ message: "Link copiado para a área de transferência!", type: 'success' });
      }
    } catch (err) {
      console.error("Erro ao compartilhar:", err);
    }
  };

  // Record visit on load
  useEffect(() => {
    const recordVisit = async () => {
      // Check if config is valid
      if (firebaseConfig.apiKey === 'TODO_KEYHERE' || !firebaseConfig.apiKey) {
        setToast({ message: "Firebase não configurado. Clique na engrenagem para ver o status.", type: 'error' });
        return;
      }

      try {
        // Test connection first
        await getDocFromServer(doc(db, 'test', 'connection'));
        
        await addDoc(collection(db, 'visits'), {
          timestamp: serverTimestamp(),
          userAgent: navigator.userAgent
        });
      } catch (error: any) {
        console.error("Erro ao registrar visita ou testar conexão:", error);
        if (error.message?.includes('the client is offline')) {
          setToast({ message: "Firebase Offline: Verifique sua configuração ou conexão.", type: 'error' });
        }
      }
    };
    recordVisit();
  }, []);

  const handleWalletConnect = async () => {
    try {
      const address = await blockchain.connectWallet();
      if (address) {
        setWalletAddress(address);
        setToast({ message: `Carteira conectada: ${address.slice(0, 6)}...${address.slice(-4)}`, type: 'success' });
        
        // Se o endereço for o do admin (opcional, aqui apenas simulamos)
        // setIsAdmin(true); 
      }
    } catch (err: any) {
      setToast({ message: err.message || "Erro ao conectar carteira", type: 'error' });
    }
  };

  const verifyAllIntegrity = async () => {
    setIsVerifyingBlockchain(true);
    let allValid = true;
    
    for (const product of products) {
      if (product.blockchainHash) {
        const isValid = await blockchain.verifyIntegrity(product, product.blockchainHash);
        if (!isValid) {
          allValid = false;
          break;
        }
      }
    }
    
    setIsVerifyingBlockchain(false);
    if (allValid) {
      setToast({ message: "Integridade da Blockchain verificada: Todos os produtos são autênticos.", type: 'success' });
    } else {
      setToast({ message: "ALERTA: Falha na verificação de integridade! Alguns dados podem ter sido alterados.", type: 'error' });
    }
  };

  const testApiKey = async (keyToTest: string) => {
    if (!keyToTest) {
      setToast({ message: "Insira uma chave para testar.", type: 'error' });
      return;
    }
    
    setIsTestingKey(true);
    try {
      const ai = new GoogleGenAI({ apiKey: keyToTest });
      
      // Helper for retry
      const callWithRetry = async (fn: () => Promise<any>, retries = 3) => {
        for (let i = 0; i <= retries; i++) {
          try {
            return await fn();
          } catch (err: any) {
            const errStr = err.message || JSON.stringify(err);
            const isRetryable = errStr.includes('503') || 
                               errStr.includes('UNAVAILABLE') || 
                               errStr.includes('high demand') ||
                               errStr.includes('temporary');
            
            if (i < retries && isRetryable) {
              // Exponential backoff: 1s, 2s, 4s
              await new Promise(r => setTimeout(r, Math.pow(2, i) * 1000));
              continue;
            }
            throw err;
          }
        }
      };

      const model = await callWithRetry(() => ai.models.get({ model: "gemini-flash-latest" }));
      
      // Try a very simple generation to be sure
      const result = await callWithRetry(() => ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: "Oi",
        config: { maxOutputTokens: 1 }
      }));
      
      if (result.text) {
        setToast({ message: "Chave válida! Conexão estabelecida com sucesso.", type: 'success' });
      }
    } catch (err: any) {
      console.error("Erro ao testar chave:", err);
      let msg = "Chave inválida ou erro de conexão.";
      if (err.message?.includes('API key not valid')) msg = "Chave API inválida. Verifique se copiou corretamente.";
      else if (err.message?.includes('Quota exceeded')) msg = "Limite de cota atingido para esta chave.";
      else if (JSON.stringify(err).includes('503') || JSON.stringify(err).includes('UNAVAILABLE') || JSON.stringify(err).includes('high demand')) {
        msg = "Os servidores da IA estão com alta demanda. A chave parece correta, mas tente testar novamente em alguns segundos.";
      }
      else if (JSON.stringify(err).includes('503') || JSON.stringify(err).includes('UNAVAILABLE') || JSON.stringify(err).includes('high demand')) {
        msg = "Os servidores da IA estão com alta demanda. A chave parece correta, mas tente testar novamente em alguns segundos.";
      }
      
      setToast({ message: msg, type: 'error' });
    } finally {
      setIsTestingKey(false);
    }
  };

  const handleFirestoreError = (error: unknown, operationType: OperationType, path: string | null) => {
    const errInfo: FirestoreErrorInfo = {
      error: error instanceof Error ? error.message : String(error),
      authInfo: {
        userId: auth.currentUser?.uid,
        email: auth.currentUser?.email,
        emailVerified: auth.currentUser?.emailVerified,
        isAnonymous: auth.currentUser?.isAnonymous,
        tenantId: auth.currentUser?.tenantId,
        providerInfo: auth.currentUser?.providerData.map(provider => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL
        })) || []
      },
      operationType,
      path
    };
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    
    // Silenciar erros de domínio não autorizado para não poluir a tela
    if (errInfo.error.includes('auth/unauthorized-domain') || errInfo.error.includes('unauthorized-domain')) {
      setToast({ 
        message: 'Domínio não autorizado: Adicione ' + window.location.hostname + ' no painel do Firebase (Authentication > Settings > Authorized Domains).', 
        type: 'error' 
      });
      return errInfo;
    }
    
    if (errInfo.error.includes('permission-denied') || errInfo.error.includes('Missing or insufficient permissions')) {
      setToast({ 
        message: 'Erro de permissão: Certifique se está logado como admin (dashfire@gmail.com) e se o domínio está autorizado no Firebase.', 
        type: 'error' 
      });
    } else {
      setToast({ message: `Erro no banco: ${errInfo.error}`, type: 'error' });
    }
    
    return errInfo;
  };

  // Handle Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user && user.email === 'dashfire@gmail.com') {
        setIsAdmin(true);
      } else {
        setIsAdmin(false);
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Test connection
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  // Load products from Firestore
  useEffect(() => {
    // Fetch dynamic config (API Key) if not already set by VITE_GEMINI_API_KEY
    if (!dynamicAiKey) {
      fetch('/api/config')
        .then(async res => {
          if (!res.ok) return null;
          const contentType = res.headers.get("content-type");
          if (contentType && contentType.includes("application/json")) {
            return res.json();
          }
          // If it's not JSON, it might be the SPA fallback (HTML)
          const text = await res.text();
          if (text.trim().startsWith('{')) {
            try {
              return JSON.parse(text);
            } catch (e) {
              return null;
            }
          }
          return null;
        })
        .then(data => {
          if (data && data.geminiApiKey) setDynamicAiKey(data.geminiApiKey);
        })
        .catch(err => {
          console.log("Configuração dinâmica não disponível via API");
        });
    }

    const q = query(collection(db, 'products'), orderBy('clickCount', 'desc'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const productsData: Product[] = [];
      snapshot.forEach((doc) => {
        productsData.push({ id: doc.id, ...doc.data() } as Product);
      });
      setProducts(productsData);
      // Salva cópia local para emergência
      localStorage.setItem('cached_products', JSON.stringify(productsData));
      setIsInitialLoading(false);
    }, (error) => {
      console.warn("Firebase offline ou erro de permissão/índice, tentando sem ordenação.");
      // Fallback: Tenta buscar sem ordenação se falhar (ex: índice faltando)
      const fallbackQ = query(collection(db, 'products'));
      onSnapshot(fallbackQ, (snapshot) => {
        const productsData: Product[] = [];
        snapshot.forEach((doc) => {
          productsData.push({ id: doc.id, ...doc.data() } as Product);
        });
        // Sort in memory as fallback
        const sortedData = [...productsData].sort((a, b) => {
          const clicksA = a.clickCount || 0;
          const clicksB = b.clickCount || 0;
          if (clicksA !== clicksB) return clicksB - clicksA;
          return (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0);
        });
        setProducts(sortedData);
        setIsInitialLoading(false);
      }, (fallbackError) => {
        console.error("Erro fatal no Firestore:", fallbackError);
        const cached = localStorage.getItem('cached_products');
        if (cached) {
          setProducts(JSON.parse(cached));
        }
        handleFirestoreError(fallbackError, OperationType.LIST, 'products');
        setIsInitialLoading(false);
      });
    });

    return () => unsubscribe();
  }, []);

  // Migration: Ensure all products have a clickCount
  useEffect(() => {
    if (isAdmin && products.length > 0) {
      const updateMissingClickCounts = async () => {
        const batch: Promise<void>[] = [];
        products.forEach(product => {
          if (product.clickCount === undefined) {
            const productRef = doc(db, 'products', product.id);
            batch.push(updateDoc(productRef, { clickCount: 0 }));
          }
        });
        if (batch.length > 0) {
          try {
            await Promise.all(batch);
            setToast({ message: `${batch.length} produtos atualizados com contador de cliques.`, type: 'success' });
          } catch (error) {
            console.error("Erro ao migrar contadores de cliques:", error);
          }
        }
      };
      updateMissingClickCounts();
    }
  }, [isAdmin, products.length]);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const filteredProducts = useMemo(() => {
    if (selectedCategory === 'Minha Lista') {
      return products.filter(p => wishlist.includes(p.id));
    }
    if (selectedCategory === 'Todos') return products;
    return products.filter(p => p.category === selectedCategory);
  }, [selectedCategory, products, wishlist]);

  const handleQuickScrape = async () => {
    if (!importText.trim() || !importText.includes('http')) {
      setToast({ message: "Insira um link válido para a raspagem direta.", type: 'error' });
      return;
    }
    
    setIsImporting(true);
    try {
      const scrapeRes = await fetch('/api/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: importText })
      });
      
      if (scrapeRes.ok) {
        const scrapeData = await scrapeRes.json();
        
        setNewProduct(prev => ({
          ...prev,
          title: scrapeData.title || prev.title,
          imageUrl: scrapeData.imageUrl || prev.imageUrl,
          price: scrapeData.price || prev.price,
          originalPrice: scrapeData.originalPrice || prev.originalPrice,
          affiliateLink: importText,
          platform: importText.includes('mercadolivre') ? 'Mercado Livre' : 
                    importText.includes('shopee') ? 'Shopee' : 
                    importText.includes('amazon') ? 'Amazon' : 'Outra'
        }));
        
        setImportText('');
        setToast({ message: "Dados básicos extraídos via raspagem direta!", type: 'success' });
      } else {
        throw new Error("Falha na raspagem direta.");
      }
    } catch (error) {
      console.error("Erro na raspagem direta:", error);
      setToast({ message: "Não foi possível extrair dados deste link. Tente o Importador Inteligente ou preencha manualmente.", type: 'error' });
    } finally {
      setIsImporting(false);
    }
  };
  
  const generateAIDescription = async () => {
    if (!newProduct.title) {
      setToast({ message: "Insira um título para gerar a descrição.", type: 'error' });
      return;
    }

    const aiKey = localAiKey || dynamicAiKey;
    if (!aiKey) {
      setToast({ message: "IA indisponível: Chave não configurada.", type: 'error' });
      setIsSettingsOpen(true);
      return;
    }

    setIsGeneratingDescription(true);
    try {
      const ai = new GoogleGenAI({ apiKey: aiKey });
      const prompt = `Crie uma descrição curta, vendedora e persuasiva para o produto "${newProduct.title}". 
      Use emojis e foque nos benefícios. Máximo de 150 caracteres. Reposta limpa, apenas o texto.`;
      
      const response = await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: prompt
      });
      
      if (response.text) {
        setNewProduct(prev => ({ ...prev, description: response.text.trim() }));
        setToast({ message: "Descrição gerada pela IA!", type: 'success' });
      }
    } catch (error) {
      console.error("Erro ao gerar descrição:", error);
      setToast({ message: "Erro ao conectar com a IA.", type: 'error' });
    } finally {
      setIsGeneratingDescription(false);
    }
  };

  const handleImageAnalysis = async (file: File) => {
    const aiKey = localAiKey || dynamicAiKey;
    if (!aiKey) {
      setToast({ message: "IA Vision indisponível: Chave não configurada.", type: 'error' });
      setIsSettingsOpen(true);
      return;
    }

    setIsAnalyzingImage(true);
    
    try {
      // Helper to convert file to base64
      const fileToGenerativePart = async (file: File) => {
        const base64Promise = new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
          reader.readAsDataURL(file);
        });
        return {
          inlineData: { data: await base64Promise, mimeType: file.type }
        };
      };

      const ai = new GoogleGenAI({ apiKey: aiKey });
      
      const imagePart = await fileToGenerativePart(file);
      const textPart = {
        text: `Analise esta imagem de produto e extraia as seguintes informações em JSON:
        {
          "title": "Nome curto e chamativo do produto",
          "category": "Eletrônicos, Casa, Moda, Beleza ou Games",
          "platform": "Mercado Livre, Shopee ou Amazon",
          "description": "Uma descrição vendedora de até 100 caracteres com emojis",
          "suggestedPrice": 0.0
        }
        Se não tiver certeza da plataforma, use 'Mercado Livre'. Responda APENAS o JSON no formato solicitado.`
      };

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: { parts: [imagePart, textPart] }
      });
      
      const text = response.text || '';
      
      const jsonMatch = text.match(/\{.*\}/s);
      if (jsonMatch) {
        const data = JSON.parse(jsonMatch[0]);
        setNewProduct(prev => ({
          ...prev,
          title: data.title || prev.title,
          category: data.category || prev.category,
          platform: (data.platform as any) || prev.platform,
          description: data.description || prev.description,
          price: data.suggestedPrice || prev.price
        }));
        setToast({ message: "IA Vision: Dados extraídos da imagem!", type: 'success' });
      }
    } catch (error) {
      console.error("Erro na análise de imagem:", error);
      setToast({ message: "Falha ao analisar imagem com IA.", type: 'error' });
    } finally {
      setIsAnalyzingImage(false);
    }
  };

  const handleSmartImport = async () => {
    if (!importText.trim()) return;
    
    setIsImporting(true);
    try {
      let pageContent = "";
      
      // Try backend scraper first
      if (importText.includes('http')) {
        try {
          const scrapeRes = await fetch('/api/scrape', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: importText })
          });
          if (scrapeRes.ok) {
            const scrapeData = await scrapeRes.json();
            if (scrapeData.content && scrapeData.content.length > 10) {
              pageContent = `Conteúdo da página: ${scrapeData.content}`;
            }
            if (scrapeData.imageUrl) {
              setNewProduct(prev => ({ ...prev, imageUrl: scrapeData.imageUrl }));
            }
          }
        } catch (e) {
          console.warn("Backend scraper indisponível ou falhou, usando IA direta.");
        }
      }

      const aiKey = localAiKey || dynamicAiKey;
      if (!aiKey) {
        setToast({ 
          message: 'IA indisponível: Chave não configurada. Clique na engrenagem (área do admin) para configurar.', 
          type: 'error' 
        });
        setIsImporting(false);
        setIsSettingsOpen(true);
        return;
      }

      const ai = new GoogleGenAI({ apiKey: aiKey });
        
        // Use googleSearch tool if we couldn't get page content and it's a URL
        const tools = (!pageContent && importText.includes('http')) ? [{ googleSearch: {} }] : [];
        
        try {
          const prompt = `Extraia as informações do produto deste texto ou link: "${importText}". 
            ${pageContent ? `Aqui está o conteúdo real da página para ajudar: ${pageContent}` : 'Se for um link, use a pesquisa para encontrar o título, preço e imagem do produto.'}
            
            Retorne APENAS um JSON no formato: 
            { "title": "nome", "price": 0.0, "originalPrice": 0.0, "imageUrl": "url", "platform": "Mercado Livre ou Shopee", "category": "Eletrônicos/Casa/Moda/Beleza/Games", "description": "breve" }
            
            IMPORTANTE:
            1. Se for um link de afiliado, tente encontrar o preço real e a imagem original do produto.
            2. Se não encontrar a imagem, use uma URL do Picsum (https://picsum.photos/seed/product/800/600).
            3. A descrição deve ser curta e atrativa.`;

          // Helper for retry
          const callWithRetry = async (fn: () => Promise<any>, retries = 3) => {
            for (let i = 0; i <= retries; i++) {
              try {
                return await fn();
              } catch (err: any) {
                const errStr = err.message || JSON.stringify(err);
                const isRetryable = errStr.includes('503') || 
                                   errStr.includes('UNAVAILABLE') || 
                                   errStr.includes('high demand') ||
                                   errStr.includes('temporary');
                
                if (i < retries && isRetryable) {
                  // Exponential backoff: 1s, 2s, 4s
                  await new Promise(r => setTimeout(r, Math.pow(2, i) * 1000));
                  continue;
                }
                throw err;
              }
            }
          };

          const response = await callWithRetry(() => ai.models.generateContent({
            model: "gemini-flash-latest",
            contents: prompt,
            config: {
              tools: tools as any
            }
          }));

          const text = response.text || '';
          const jsonMatch = text.match(/\{.*\}/s);
          if (jsonMatch) {
            const data = JSON.parse(jsonMatch[0]);
            
            setNewProduct(prev => {
              const updated = {
                ...prev,
                ...data,
                affiliateLink: importText.includes('http') ? importText : (prev.affiliateLink || '')
              };
              
              // Se a IA retornou uma imagem genérica (picsum) mas já temos uma imagem real do scraper, mantém a real
              if (data.imageUrl?.includes('picsum.photos') && prev.imageUrl && !prev.imageUrl.includes('picsum.photos')) {
                updated.imageUrl = prev.imageUrl;
              }
              
              return updated;
            });

            setImportText('');
            setToast({ message: "Dados extraídos com sucesso!", type: 'success' });
          } else {
            console.error("IA não retornou JSON válido:", text);
            setToast({ message: "A IA não conseguiu formatar os dados. Tente novamente ou preencha manualmente.", type: 'error' });
          }
        } catch (aiError: any) {
          console.error("Erro na chamada da IA:", aiError);
          let errorMsg = "Erro na IA: Falha na comunicação.";
          
          // Check for invalid API key error
          const errorStr = JSON.stringify(aiError);
          if (errorStr.includes('API key not valid') || aiError.message?.includes('API key not valid')) {
            errorMsg = "Chave da IA inválida. Clique na engrenagem para ajustar.";
            setIsSettingsOpen(true);
          } else if (errorStr.includes('leaked') || aiError.message?.includes('leaked')) {
            errorMsg = "Esta chave foi bloqueada pelo Google por segurança. Por favor, use uma nova chave na engrenagem.";
            setIsSettingsOpen(true);
          } else if (aiError.message?.includes('Quota exceeded')) {
            errorMsg = "Limite da IA atingido. Tente novamente mais tarde.";
          } else if (errorStr.includes('503') || errorStr.includes('UNAVAILABLE') || errorStr.includes('high demand')) {
            errorMsg = "A IA está com alta demanda no momento. Tentamos reconectar, mas os servidores do Google ainda estão ocupados. Tente novamente em alguns instantes.";
          }
          
          setToast({ message: errorMsg, type: 'error' });
        }
    } catch (error) {
      console.error("Erro na importação inteligente:", error);
      setToast({ message: "Erro ao processar importação.", type: 'error' });
    } finally {
      setIsImporting(false);
    }
  };

  const handleSyncPrices = async () => {
    if (isSyncing) return;
    
    const aiKey = localAiKey || dynamicAiKey;
    if (!aiKey) {
      setToast({ 
        message: 'IA indisponível para verificação: Chave não configurada. Clique na engrenagem para configurar.', 
        type: 'error' 
      });
      setIsSettingsOpen(true);
      return;
    }

    setIsSyncing(true);
    let updatedCount = 0;
    let errorCount = 0;
    let aiVerificationCount = 0;

    setToast({ message: `Iniciando verificação IA (${products.length} produtos)...`, type: 'info' });

    const ai = new GoogleGenAI({ apiKey: aiKey });

    for (const product of products) {
      if (!product.affiliateLink || !product.affiliateLink.includes('http')) continue;

      try {
        const response = await fetch('/api/scrape', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: product.affiliateLink })
        });

        if (response.ok) {
          const data = await response.json();
          let finalPrice = data.price;
          let finalOriginalPrice = data.originalPrice;

          // Se o scraper básico falhou ou se queremos confirmação da IA
          if (!finalPrice || finalPrice === 0 || data.content) {
            try {
              const aiPrompt = `Com base no conteúdo da página abaixo, identifique o preço ATUAL do produto e, se disponível, o preço ORIGINAL (preço de mercado/sem desconto).
              
              Conteúdo: ${data.content?.substring(0, 3000)}
              
              Retorne APENAS um JSON no formato: {"price": 0.00, "originalPrice": 0.00}. Se não encontrar, retorne 0.`;

              const aiRes = await ai.models.generateContent({
                model: "gemini-3-flash-preview",
                contents: aiPrompt,
                config: { responseMimeType: "application/json" }
              });

              const aiData = JSON.parse(aiRes.text || '{}');
              if (aiData.price && aiData.price > 0) {
                finalPrice = aiData.price;
                if (aiData.originalPrice) finalOriginalPrice = aiData.originalPrice;
                aiVerificationCount++;
              }
            } catch (aiErr) {
              console.warn(`IA falhou para ${product.title}, usando dados do scraper.`);
            }
          }

          if (finalPrice && finalPrice !== product.price) {
            // Gerar novo hash para manter integridade na blockchain
            const newBlockchainHash = await blockchain.generateProductHash({
              ...product,
              price: finalPrice,
              originalPrice: finalOriginalPrice || product.originalPrice || null,
            });

            await updateDoc(doc(db, 'products', product.id), {
              price: finalPrice,
              originalPrice: finalOriginalPrice || product.originalPrice || null,
              blockchainHash: newBlockchainHash,
              lastSyncAt: serverTimestamp()
            });
            updatedCount++;
          } else {
            await updateDoc(doc(db, 'products', product.id), {
              lastSyncAt: serverTimestamp()
            });
          }
        }
      } catch (error) {
        console.error(`Falha ao sincronizar: ${product.title}`, error);
        errorCount++;
      }
      
      // Pequeno delay para evitar rate limit
      await new Promise(r => setTimeout(r, 500));
    }

    setIsSyncing(false);
    setToast({ 
      message: `IA & Blockchain: ${updatedCount} preços corrigidos. ${aiVerificationCount} verificações profundas realizadas. ${errorCount} erros.`, 
      type: updatedCount > 0 ? 'success' : 'info' 
    });
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.title || !newProduct.price || !newProduct.affiliateLink || !newProduct.imageUrl) {
      setToast({ message: 'Por favor, preencha os campos obrigatórios.', type: 'error' });
      return;
    }

    // 1. Get or Generate ID first to ensure blockchain hash consistency
    const productId = editingProductId || doc(collection(db, 'products')).id;

    // 2. Generate Blockchain Hash for the product to ensure integrity
    const blockchainHash = await blockchain.generateProductHash({
      title: newProduct.title!,
      price: Number(newProduct.price),
      link: newProduct.affiliateLink!,
      id: productId,
      createdAt: editingProductId ? (newProduct as any).createdAt : Date.now()
    });

    const productData = {
      title: newProduct.title!,
      description: newProduct.description || '',
      price: Number(newProduct.price),
      originalPrice: newProduct.originalPrice ? Number(newProduct.originalPrice) : null,
      imageUrl: newProduct.imageUrl!,
      affiliateLink: newProduct.affiliateLink!,
      platform: newProduct.platform,
      category: newProduct.category,
      isHot: newProduct.isHot || false,
      rating: newProduct.rating ? Number(newProduct.rating) : 5,
      clickCount: editingProductId ? (newProduct.clickCount || 0) : 0,
      blockchainHash, // Store the hash
      createdAt: editingProductId ? (newProduct as any).createdAt : serverTimestamp(),
    };

    try {
      // Fallback Local: Salva localmente primeiro para garantir que o usuário não perca o trabalho
      const localProduct = { ...productData, id: productId } as Product;
      const updatedLocalProducts = editingProductId 
        ? products.map(p => p.id === editingProductId ? localProduct : p)
        : [localProduct, ...products];
      
      localStorage.setItem('cached_products', JSON.stringify(updatedLocalProducts));
      if (!auth.currentUser) {
        setProducts(updatedLocalProducts);
        setToast({ 
          message: 'Salvo localmente. Para salvar na nuvem, você deve entrar com Google (ícone de perfil).', 
          type: 'warning' 
        });
        setIsModalOpen(false);
        return;
      }

      if (editingProductId) {
        await updateDoc(doc(db, 'products', editingProductId), productData);
        setToast({ message: 'Produto atualizado com sucesso!', type: 'success' });
      } else {
        await setDoc(doc(db, 'products', productId), productData);
        setToast({ message: 'Produto cadastrado com sucesso!', type: 'success' });
      }
      
      setIsModalOpen(false);
      setEditingProductId(null);
      setNewProduct({ platform: 'Mercado Livre', category: 'Eletrônicos' });
    } catch (error: any) {
      if (error.message?.includes('permission-denied') || error.message?.includes('Missing or insufficient permissions')) {
        setToast({ message: 'Salvo apenas localmente (Erro de permissão no Firebase).', type: 'warning' });
        setIsModalOpen(false);
      } else {
        handleFirestoreError(error, editingProductId ? OperationType.UPDATE : OperationType.CREATE, `products/${editingProductId || ''}`);
      }
    }
  };

  const openEditModal = (product: Product) => {
    setEditingProductId(product.id);
    setNewProduct(product);
    setIsModalOpen(true);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewProduct(prev => ({ ...prev, imageUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeProduct = async (id: string) => {
    try {
      if (!auth.currentUser) {
        setToast({ message: 'Erro: Você precisa estar logado com Google para remover produtos.', type: 'error' });
        setIsLoginModalOpen(true);
        return;
      }
      await deleteDoc(doc(db, 'products', id));
      setToast({ message: 'Produto removido com sucesso!', type: 'success' });
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `products/${id}`);
    }
  };

  const clearAllProducts = async () => {
    setConfirmConfig({
      isOpen: true,
      title: 'Remover Tudo',
      message: 'Tem certeza que deseja remover TODOS os produtos? Esta ação não pode ser desfeita.',
      onConfirm: async () => {
        try {
          if (!auth.currentUser) {
            setToast({ message: 'Erro: Você precisa estar logado com Google para remover produtos.', type: 'error' });
            setIsLoginModalOpen(true);
            return;
          }
          const deletePromises = products.map(p => deleteDoc(doc(db, 'products', p.id)));
          await Promise.all(deletePromises);
          setToast({ message: 'Todos os produtos foram removidos.', type: 'success' });
        } catch (error) {
          handleFirestoreError(error, OperationType.DELETE, 'products/all');
        }
      }
    });
  };

  const handleAdminLogin = () => {
    setIsLoginModalOpen(true);
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      setToast({ message: 'Sessão encerrada.', type: 'success' });
    } catch (error) {
      console.error('Erro ao sair:', error);
    }
  };

  const onLoginSuccess = (password: string) => {
    setIsAdmin(true);
    setIsLoginModalOpen(false);
    setToast({ message: 'Acesso concedido! Modo administrador ativado.', type: 'success' });
  };

  if (isInitialLoading) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center gap-4">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full"
        />
        <p className="text-gray-500 font-medium animate-pulse">Carregando as melhores ofertas...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FDFDFD] font-sans text-gray-900">
      <div className="bg-orange-600 text-white py-2 px-4 text-center text-[11px] font-bold uppercase tracking-[0.2em] relative z-[60]">
        <span className="flex items-center justify-center gap-4">
          <span className="flex items-center gap-1"><ShieldCheck size={12} /> Links Verificados</span>
          <span className="hidden sm:inline opacity-50">|</span>
          <span className="flex items-center gap-1"><Star size={12} fill="currentColor" /> Melhores Ofertas de Hoje</span>
          <span className="hidden sm:inline opacity-50">|</span>
          <span className="flex items-center gap-1">🚀 Revisão técnica a cada 24h</span>
        </span>
      </div>
      <Navbar 
        isAdmin={isAdmin} 
        onAdminLogin={handleAdminLogin} 
        onLogout={handleLogout} 
        onOpenSettings={() => setIsSettingsOpen(true)}
      />
      
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 50, x: '-50%' }}
            className={`fixed bottom-8 left-1/2 z-[200] px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 font-bold text-white ${
              toast.type === 'success' ? 'bg-emerald-500' : 'bg-red-500'
            }`}
          >
            {toast.type === 'success' ? <Zap size={20} /> : <AlertCircle size={20} />}
            {toast.message}
          </motion.div>
        )}
      </AnimatePresence>

      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
        onLogin={onLoginSuccess} 
      />

      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        title={confirmConfig.title}
        message={confirmConfig.message}
        onConfirm={confirmConfig.onConfirm}
        onClose={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
      />

      {/* Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl border border-black/5"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Settings className="text-orange-500" />
                Configuração IA
              </h2>
              <button onClick={() => setIsSettingsOpen(false)} className="text-gray-400 hover:text-gray-900 transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Gemini API Key</label>
                <p className="text-[10px] text-gray-500 mb-2">
                  Obtenha uma chave gratuita em: <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-orange-500 underline">Google AI Studio</a>
                </p>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={localAiKey}
                    onChange={(e) => {
                      const val = e.target.value;
                      setLocalAiKey(val);
                      localStorage.setItem('gemini_api_key', val);
                    }}
                    placeholder="Cole sua chave aqui..."
                    className="flex-1 bg-gray-50 border border-gray-200 rounded-2xl px-5 py-4 text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all"
                  />
                  <button
                    onClick={() => testApiKey(localAiKey)}
                    disabled={isTestingKey}
                    className="px-4 bg-orange-100 text-orange-600 rounded-2xl font-bold hover:bg-orange-200 transition-colors disabled:opacity-50"
                  >
                    {isTestingKey ? '...' : 'Testar'}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-3 leading-relaxed">
                  Esta chave é salva <strong>apenas no seu navegador</strong>. Ela permite que a importação inteligente funcione mesmo em servidores estáticos como o Netlify.
                </p>
              </div>
              
              <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl">
                <p className="text-xs text-orange-700 leading-relaxed">
                  <strong>Dica Netlify:</strong> Se as postagens falharem, lembre-se de adicionar o domínio do seu site no painel do Firebase (Authentication {'>'} Settings {'>'} Authorized Domains).
                </p>
              </div>

              <div className="p-4 bg-gray-50 border border-gray-200 rounded-2xl space-y-2">
                <h3 className="text-xs font-bold text-gray-700 uppercase tracking-wider">Status Firebase</h3>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-gray-500">Configuração:</span>
                  <span className={firebaseConfig.apiKey !== 'TODO_KEYHERE' ? 'text-green-600 font-bold' : 'text-red-600 font-bold'}>
                    {firebaseConfig.apiKey !== 'TODO_KEYHERE' ? 'Válida' : 'Pendente'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-gray-500">Usuário Logado:</span>
                  <span className={auth.currentUser ? 'text-green-600 font-bold' : 'text-amber-600 font-bold'}>
                    {auth.currentUser ? auth.currentUser.email : 'Nenhum'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-gray-500">Domínio Atual:</span>
                  <span className="text-gray-900">{window.location.hostname}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setIsSettingsOpen(false);
                setToast({ message: 'Configurações salvas com sucesso!', type: 'success' });
              }}
              className="w-full mt-8 bg-black hover:bg-gray-800 text-white font-bold py-4 rounded-2xl transition-all shadow-lg shadow-black/10"
            >
              Salvar e Fechar
            </button>
          </motion.div>
        </div>
      )}

      <StatsDashboard 
        isOpen={isStatsOpen} 
        onClose={() => setIsStatsOpen(false)} 
      />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white pt-16 pb-24 border-b border-black/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1 max-w-2xl">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-orange-50 text-orange-600 text-[10px] font-extrabold uppercase tracking-widest mb-8 border border-orange-100 shadow-sm">
                  <span className="flex h-2 w-2 rounded-full bg-orange-500 animate-ping" />
                  Atualizado agora mesmo
                </div>
                <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-gray-950 mb-8 leading-[1.05]">
                  Os Melhores <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-red-600">Achadinhos</span> Selecionados.
                </h1>
                <p className="text-lg text-gray-500 mb-10 leading-relaxed font-medium">
                  Encontramos os menores preços e as ofertas mais quentes do Mercado Livre e outras plataformas para você não perder tempo pesquisando.
                </p>
                
                <div className="flex flex-wrap gap-4">
                  <a 
                    href="#ofertas" 
                    className="px-10 py-5 bg-orange-600 text-white rounded-2xl font-bold hover:bg-orange-700 transition-all flex items-center gap-3 shadow-xl shadow-orange-200 hover:scale-105 active:scale-95"
                  >
                    Explorar Ofertas
                    <Zap size={20} fill="currentColor" />
                  </a>
                  {isAdmin && (
                    <>
                      <button 
                        onClick={() => setIsModalOpen(true)}
                        className="px-8 py-5 bg-gray-950 text-white rounded-2xl font-bold hover:bg-gray-800 transition-all flex items-center gap-2 shadow-xl shadow-gray-200"
                      >
                        <Plus size={20} />
                        Novo Produto
                      </button>
                      <button 
                        onClick={handleSyncPrices}
                        disabled={isSyncing}
                        className="px-8 py-5 bg-white border border-gray-200 text-gray-950 rounded-2xl font-bold hover:bg-gray-50 transition-all flex items-center gap-2 shadow-xl shadow-gray-100 disabled:opacity-50"
                        title="Usa Inteligência Artificial para verificar preços e Blockchain para garantir integridade"
                      >
                        <ShieldCheck size={20} className={isSyncing ? "animate-pulse text-orange-500" : "text-orange-500"} />
                        {isSyncing ? "Verificando com IA..." : "Sincronização IA & Blockchain"}
                      </button>
                    </>
                  )}
                </div>
                
                <div className="mt-12 flex items-center gap-6">
                  <div className="flex -space-x-3">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-gray-100 overflow-hidden shadow-sm">
                        <img src={`https://i.pravatar.cc/100?img=${i+10}`} alt="User" />
                      </div>
                    ))}
                  </div>
                  <div className="text-sm font-medium text-gray-500">
                    <span className="text-gray-900 font-bold">+2.500 pessoas</span> economizando hoje
                  </div>
                </div>
              </motion.div>
            </div>
            
            <div className="flex-1 relative hidden lg:block">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2, duration: 0.8 }}
                className="relative"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-orange-400 to-red-500 rounded-full blur-[100px] opacity-20 animate-pulse" />
                <div className="relative bg-white p-6 rounded-[2.5rem] shadow-2xl border border-black/5 rotate-3 hover:rotate-0 transition-transform duration-700">
                  <img 
                    src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&q=80&w=600" 
                    alt="Shopping" 
                    className="rounded-[2rem] w-full aspect-[4/5] object-cover"
                  />
                  <div className="absolute -bottom-10 -left-10 bg-white p-6 rounded-3xl shadow-2xl border border-black/5 max-w-[180px] -rotate-6">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1.5 bg-orange-100 text-orange-600 rounded-lg">
                        <Star size={16} fill="currentColor" />
                      </div>
                      <span className="text-xs font-bold">Favorito</span>
                    </div>
                    <p className="text-[11px] text-gray-500 font-medium">Os produtos mais desejados com descontos reais.</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[600px] h-[600px] bg-orange-50 rounded-full blur-3xl opacity-50 -z-0" />
        <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[400px] h-[400px] bg-blue-50 rounded-full blur-3xl opacity-50 -z-0" />
      </section>

      {/* Advertisement Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-10">
        <a 
          href="https://www.profitablecpmratenetwork.com/ubb8kaqc?key=250d1b5c95fb900a79457bf9fc040348" 
          target="_blank" 
          rel="noopener noreferrer"
          className="block group"
        >
          <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-3xl p-1 shadow-xl shadow-orange-200/50 transition-transform hover:scale-[1.01] active:scale-[0.99]">
            <div className="bg-white/10 backdrop-blur-md rounded-[22px] px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-6 overflow-hidden relative">
              <div className="absolute top-4 right-6 z-20">
                <span className="text-[10px] font-bold uppercase tracking-widest text-white/40 border border-white/20 px-2 py-1 rounded-md">Patrocinado</span>
              </div>
              <div className="flex items-center gap-6 relative z-10">
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg text-orange-600 shrink-0">
                  <Sparkles size={32} />
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bold text-white mb-1">Oferta Especial do Dia!</h3>
                  <p className="text-orange-50 text-sm md:text-base opacity-90">Confira esta oportunidade imperdível que selecionamos para você hoje.</p>
                </div>
              </div>
              <div className="relative z-10">
                <span className="px-8 py-4 bg-white text-orange-600 rounded-2xl font-bold text-lg shadow-lg group-hover:bg-orange-50 transition-colors flex items-center gap-2">
                  Ver Oferta Agora
                  <ArrowUpRight size={20} />
                </span>
              </div>
              
              {/* Decorative background elements for the ad */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-black/5 rounded-full translate-y-1/2 -translate-x-1/2 blur-xl" />
            </div>
          </div>
        </a>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Category Filter */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          {isAdmin && (
            <div className="flex flex-col gap-4 flex-1">
              <div className={`p-4 rounded-2xl border flex items-center justify-between ${
                auth.currentUser 
                  ? 'bg-green-50 border-green-100 text-green-700' 
                  : 'bg-amber-50 border-amber-100 text-amber-700'
              }`}>
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full animate-pulse ${auth.currentUser ? 'bg-green-500' : 'bg-amber-500'}`} />
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider">
                      {auth.currentUser ? 'Sincronizado com Nuvem' : 'Modo Local (Offline)'}
                    </p>
                    <p className="text-[10px] opacity-80">
                      {auth.currentUser 
                        ? `Logado: ${auth.currentUser.email}` 
                        : 'Dados salvos apenas neste navegador. Autorize o domínio no Firebase para nuvem.'}
                    </p>
                  </div>
                </div>
                {!auth.currentUser && (
                  <button 
                    onClick={() => setIsLoginModalOpen(true)}
                    className="text-[10px] bg-amber-200/50 hover:bg-amber-200 px-3 py-1.5 rounded-lg font-bold transition-colors"
                  >
                    Conectar Nuvem
                  </button>
                )}
              </div>

              {/* Blockchain Security Panel */}
              <div className="p-4 rounded-2xl border border-blue-100 bg-blue-50/50 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-xl text-blue-600">
                    <ShieldCheck size={18} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-blue-900 uppercase tracking-wider">Segurança Blockchain</p>
                    <p className="text-[10px] text-blue-700">
                      {walletAddress 
                        ? `Carteira: ${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}` 
                        : 'Proteja o site com autenticação Web3 e integridade de dados.'}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {!walletAddress ? (
                    <button 
                      onClick={handleWalletConnect}
                      className="text-[10px] bg-blue-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-blue-700 transition-all flex items-center gap-2"
                    >
                      <Wallet size={14} />
                      Conectar Carteira
                    </button>
                  ) : (
                    <button 
                      onClick={verifyAllIntegrity}
                      disabled={isVerifyingBlockchain}
                      className="text-[10px] bg-white border border-blue-200 text-blue-700 px-3 py-1.5 rounded-lg font-bold hover:bg-blue-50 transition-all flex items-center gap-2 disabled:opacity-50"
                    >
                      {isVerifyingBlockchain ? (
                        <Wand2 size={14} className="animate-spin" />
                      ) : (
                        <ShieldCheck size={14} />
                      )}
                      Verificar Integridade
                    </button>
                  )}
                  <button 
                    onClick={() => setIsStatsOpen(true)}
                    className="text-[10px] bg-orange-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-orange-700 transition-all flex items-center gap-2"
                  >
                    <BarChart3 size={14} />
                    Estatísticas
                  </button>
                </div>
              </div>
            </div>
          )}
          <div className="flex items-center gap-4 overflow-x-auto pb-4 no-scrollbar scroll-smooth">
            {wishlist.length > 0 && (
              <button
                key="wishlist"
                onClick={() => setSelectedCategory('Minha Lista' as any)}
                className={`px-6 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all flex items-center gap-2 ${
                  selectedCategory === 'Minha Lista' 
                    ? 'bg-orange-500 text-white shadow-lg shadow-orange-200 scale-105' 
                    : 'bg-white text-orange-600 border border-orange-100 hover:bg-orange-50'
                }`}
              >
                <Heart size={16} fill={selectedCategory === 'Minha Lista' ? "currentColor" : "none"} />
                Minha Lista ({wishlist.length})
              </button>
            )}
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat as Category)}
                className={`px-6 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                  selectedCategory === cat 
                    ? 'bg-black text-white shadow-xl shadow-gray-200 scale-105 border-transparent' 
                    : 'bg-white text-gray-600 border border-black/5 hover:border-black/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          
          <div className="flex items-center gap-2 text-sm text-gray-500 font-medium">
            <Star size={16} className="text-yellow-400 fill-yellow-400" />
            <span>Mostrando {filteredProducts.length} ofertas selecionadas</span>
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 px-1">
          {filteredProducts.map((product) => (
            <div key={product.id} className="relative group h-full">
              <ProductCard 
                product={product} 
                isWishlisted={wishlist.includes(product.id)}
                onWishlistToggle={toggleWishlist}
                onShare={shareProduct}
              />
              {isAdmin && (
                <div className="absolute top-2 right-2 z-20 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => openEditModal(product)}
                    className="bg-white text-black p-2 rounded-full shadow-lg hover:bg-gray-100"
                    title="Editar Produto"
                  >
                    <Pencil size={16} />
                  </button>
                  <button 
                    onClick={() => removeProduct(product.id)}
                    className="bg-red-500 text-white p-2 rounded-full shadow-lg hover:bg-red-600"
                    title="Remover Produto"
                  >
                    <X size={16} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-400">
              <ShoppingBag size={40} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Nenhuma oferta encontrada</h3>
            <p className="text-gray-500">Tente mudar a categoria ou adicione novos produtos.</p>
          </div>
        )}
      </main>

      {/* Modal de Cadastro */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl"
            >
              <div className="p-6 border-b border-black/5 flex justify-between items-center sticky top-0 bg-white z-10">
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  {editingProductId ? <Tag className="text-orange-500" /> : <Plus className="text-orange-500" />}
                  {editingProductId ? 'Editar Produto' : 'Novo Produto'}
                </h2>
                <button onClick={() => {
                  setIsModalOpen(false);
                  setEditingProductId(null);
                  setNewProduct({ platform: 'Mercado Livre', category: 'Eletrônicos' });
                }} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <X size={24} />
                </button>
              </div>

              <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto no-scrollbar">
                {/* AI Toolkit Section */}
                <div className="flex flex-col gap-4">
                  {/* IA Vision Search */}
                  <div className="bg-gradient-to-br from-indigo-50 to-blue-50/30 rounded-3xl p-6 border border-indigo-100 shadow-sm">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100">
                          {isAnalyzingImage ? <Sparkles size={24} className="animate-spin" /> : <ImageIcon size={24} />}
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-900">Busca por Imagem (IA Vision)</h4>
                          <p className="text-[10px] text-gray-500 font-medium uppercase tracking-wider">Identificação Automática</p>
                        </div>
                      </div>
                      <label className="cursor-pointer bg-white text-indigo-600 px-5 py-2.5 rounded-2xl font-bold text-xs border border-indigo-100 hover:bg-indigo-50 transition-all shadow-sm active:scale-95">
                        {isAnalyzingImage ? "Analisando..." : "Subir Foto"}
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleImageAnalysis(file);
                          }}
                          disabled={isAnalyzingImage}
                        />
                      </label>
                    </div>
                  </div>

                  {/* Smart Import Link */}
                  <div className="bg-gradient-to-br from-orange-50 to-yellow-50/30 rounded-3xl p-6 border border-orange-100 shadow-sm text-sm">
                    <h3 className="text-sm font-bold text-orange-800 flex items-center gap-2 mb-3">
                      <Sparkles size={16} /> Importador Inteligente (IA)
                    </h3>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input 
                        type="text" 
                        placeholder="Cole o link ou texto da oferta..."
                        className="flex-1 px-4 py-3 bg-white border border-orange-200 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-orange-300 transition-all"
                        value={importText}
                        onChange={e => setImportText(e.target.value)}
                      />
                      <div className="flex gap-2">
                        <button 
                          onClick={handleSmartImport}
                          disabled={isImporting || !importText.trim()}
                          className="flex-1 sm:flex-none bg-orange-500 text-white px-5 py-2 rounded-2xl font-bold text-sm hover:bg-orange-600 transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg shadow-orange-100"
                        >
                          {isImporting ? <Wand2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
                          IA
                        </button>
                        <button 
                          onClick={handleQuickScrape}
                          disabled={isImporting || !importText.trim() || !importText.includes('http')}
                          className="flex-1 sm:flex-none bg-white border border-orange-200 text-orange-600 px-5 py-2 rounded-2xl font-bold text-sm hover:bg-orange-50 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                        >
                          <Zap size={18} className="text-yellow-500" />
                          Link
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <form onSubmit={handleAddProduct} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <Tag size={16} /> Título do Produto *
                      </label>
                      <input 
                        required
                        type="text" 
                        placeholder="Ex: Smartphone Samsung Galaxy S23"
                        className="w-full px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none"
                        value={newProduct.title || ''}
                        onChange={e => setNewProduct({...newProduct, title: e.target.value})}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <Info size={16} /> Plataforma
                      </label>
                      <select 
                        className="w-full px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none"
                        value={newProduct.platform}
                        onChange={e => setNewProduct({...newProduct, platform: e.target.value as any})}
                      >
                        <option value="Mercado Livre">Mercado Livre</option>
                        <option value="Shopee">Shopee</option>
                        <option value="Amazon">Amazon</option>
                        <option value="Outros">Outros</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">Preço Atual (R$) *</label>
                      <input 
                        required
                        type="number" 
                        step="0.01"
                        placeholder="0,00"
                        className="w-full px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none"
                        value={newProduct.price || ''}
                        onChange={e => setNewProduct({...newProduct, price: Number(e.target.value)})}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">Preço Original (Opcional)</label>
                      <input 
                        type="number" 
                        step="0.01"
                        placeholder="0,00"
                        className="w-full px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none"
                        value={newProduct.originalPrice || ''}
                        onChange={e => setNewProduct({...newProduct, originalPrice: Number(e.target.value)})}
                      />
                    </div>

                    <div className="space-y-2 md:col-span-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <LinkIcon size={16} /> Link de Afiliado *
                      </label>
                      <input 
                        required
                        type="url" 
                        placeholder="https://mercadolivre.com.br/..."
                        className="w-full px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none"
                        value={newProduct.affiliateLink || ''}
                        onChange={e => setNewProduct({...newProduct, affiliateLink: e.target.value})}
                      />
                    </div>

                    <div className="space-y-2 md:col-span-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <ImageIcon size={16} /> Imagem do Produto *
                      </label>
                      <div className="flex gap-2">
                        <input 
                          required
                          type="text" 
                          placeholder="URL da imagem ou faça upload..."
                          className="flex-1 px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none"
                          value={newProduct.imageUrl || ''}
                          onChange={e => setNewProduct({...newProduct, imageUrl: e.target.value})}
                        />
                        <label className="bg-gray-100 text-gray-700 px-4 py-3 rounded-xl cursor-pointer hover:bg-gray-200 transition-colors flex items-center gap-2 border border-black/5">
                          <Upload size={18} />
                          <span className="text-xs font-bold hidden sm:inline">Upload</span>
                          <input 
                            type="file" 
                            accept="image/*" 
                            className="hidden" 
                            onChange={handleImageUpload}
                          />
                        </label>
                      </div>
                      {newProduct.imageUrl && (
                        <div className="mt-2 relative w-20 h-20 rounded-lg overflow-hidden border border-black/5">
                          <img src={newProduct.imageUrl} alt="Preview" className="w-full h-full object-cover" />
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">Categoria</label>
                      <select 
                        className="w-full px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none"
                        value={newProduct.category}
                        onChange={e => setNewProduct({...newProduct, category: e.target.value as any})}
                      >
                        {CATEGORIES.filter(c => c !== 'Todos').map(c => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <Star size={16} /> Avaliação (1-5)
                      </label>
                      <input 
                        type="number" 
                        min="1"
                        max="5"
                        step="0.1"
                        placeholder="5.0"
                        className="w-full px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none"
                        value={newProduct.rating || ''}
                        onChange={e => setNewProduct({...newProduct, rating: Number(e.target.value)})}
                      />
                    </div>

                    <div className="space-y-2 md:col-span-2">
                      <div className="flex justify-between items-center">
                        <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                          <Info size={16} /> Descrição do Produto
                        </label>
                        <button
                          type="button"
                          onClick={generateAIDescription}
                          disabled={isGeneratingDescription || !newProduct.title}
                          className="text-[10px] font-bold text-orange-600 flex items-center gap-1 hover:text-orange-700 disabled:opacity-50"
                        >
                          {isGeneratingDescription ? <Wand2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
                          Gerar com IA
                        </button>
                      </div>
                      <textarea 
                        placeholder="Breve descrição do produto..."
                        className="w-full px-4 py-3 bg-gray-50 border border-black/5 rounded-xl focus:ring-2 focus:ring-black/5 outline-none min-h-[100px] text-sm"
                        value={newProduct.description || ''}
                        onChange={e => setNewProduct({...newProduct, description: e.target.value})}
                      />
                    </div>

                    <div className="flex items-center gap-3 pt-4">
                      <input 
                        type="checkbox" 
                        id="isHot"
                        className="w-5 h-5 accent-orange-500"
                        checked={newProduct.isHot || false}
                        onChange={e => setNewProduct({...newProduct, isHot: e.target.checked})}
                      />
                      <label htmlFor="isHot" className="text-sm font-bold text-gray-700 cursor-pointer">Destacar como "Em Alta"</label>
                    </div>
                  </div>

                  <div className="pt-6">
                    <button 
                      type="submit"
                      className="w-full bg-black text-white py-4 rounded-2xl font-bold hover:bg-gray-800 transition-all shadow-xl shadow-black/10"
                    >
                      Salvar Produto
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <footer className="bg-gray-950 text-white py-20 mt-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-orange-500/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-20">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white shadow-lg">
                  <ShoppingBag size={22} />
                </div>
                <span className="text-2xl font-black tracking-tighter">
                  Achadinhos<span className="text-orange-500">.</span>
                </span>
              </div>
              <p className="text-gray-400 max-w-sm mb-8 leading-relaxed">
                Nossa missão é garimpar as melhores oportunidades em plataformas confiáveis para que você compre sempre pelo menor preço.
              </p>
            </div>
            
            <div>
              <h4 className="font-bold text-white mb-8 text-sm uppercase tracking-widest">Plataformas</h4>
              <ul className="space-y-4 text-sm text-gray-400 font-medium">
                <li><a href="#" className="hover:text-orange-500 transition-colors">Shopee</a></li>
                <li><a href="#" className="hover:text-orange-500 transition-colors">Mercado Livre</a></li>
                <li><a href="#" className="hover:text-orange-500 transition-colors">Amazon</a></li>
                <li><a href="#" className="hover:text-orange-500 transition-colors">AliExpress</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold text-white mb-8 text-sm uppercase tracking-widest">Contato & Apoio</h4>
              <ul className="space-y-4 text-sm text-gray-400 font-medium">
                <li className="flex items-center gap-3 group italic">
                  <Mail size={16} className="text-orange-500 group-hover:scale-110 transition-transform" />
                  <a href="mailto:dashfire@gmail.com" className="hover:text-white transition-colors">dashfire@gmail.com</a>
                </li>
                <li className="flex items-center gap-3 group">
                  <Heart size={16} className="text-orange-500 group-hover:animate-pulse" />
                  <span>PIX: dashfire@gmail.com</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-12">
            <p className="text-[10px] text-gray-500 text-center leading-loose max-w-4xl mx-auto uppercase tracking-wider font-bold">
              ESTE SITE É UMA VITRINE DE INDICAÇÕES DE PRODUTOS DE OUTRAS PLATAFORMAS. NÃO SOMOS O VENDEDOR FINAL NEM A PLATAFORMA DE VENDAS. ATUAMOS APENAS NA INDICAÇÃO E CURADORIA DOS MELHORES ACHADINHOS.
            </p>
          </div>
          
          <div className="pt-12 flex flex-col md:flex-row justify-between items-center gap-8 text-gray-500 font-medium">
            <p className="text-xs">
              © 2026 Achadinhos PH. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-8">
              <button 
                onClick={handleAdminLogin}
                className="text-[10px] uppercase tracking-widest font-black hover:text-orange-500 transition-colors"
              >
                {isAdmin ? 'PAINEL ATIVO' : 'ADMINISTRADOR'}
              </button>
              <p className="text-[10px] uppercase tracking-widest font-black flex items-center gap-2">
                MADE BY <span className="text-orange-500">PH TEAM</span>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
