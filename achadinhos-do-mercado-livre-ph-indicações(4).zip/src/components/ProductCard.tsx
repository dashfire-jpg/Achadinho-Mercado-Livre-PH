import React, { useState } from 'react';
import { ShoppingCart, ExternalLink, Flame, ShieldCheck, Heart, Share2, Info, Sparkles, Star } from 'lucide-react';
import { Product } from '../types';
import { motion } from 'motion/react';
import { addDoc, collection, serverTimestamp, updateDoc, doc, increment } from 'firebase/firestore';
import { db } from '../firebase';

interface ProductCardProps {
  product: Product;
  onWishlistToggle?: (id: string) => void;
  isWishlisted?: boolean;
  onShare?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onWishlistToggle, 
  isWishlisted,
  onShare 
}) => {
  const [showTooltip, setShowTooltip] = useState(false);
  
  const discount = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) 
    : 0;

  const handleLinkClick = async () => {
    try {
      await addDoc(collection(db, 'clicks'), {
        productId: product.id,
        productTitle: product.title,
        platform: product.platform,
        timestamp: serverTimestamp()
      });

      const productRef = doc(db, 'products', product.id);
      await updateDoc(productRef, {
        clickCount: increment(1)
      });
    } catch (error) {
      console.error("Erro ao registrar clique:", error);
    }
  };

  const isAiVerified = product.lastSyncAt !== undefined;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      className={`bg-white rounded-3xl overflow-hidden shadow-sm border transition-all duration-300 group relative flex flex-col h-full ${
        isAiVerified 
          ? 'border-orange-500/30 ring-[3px] ring-orange-500/5 shadow-xl shadow-orange-100/50' 
          : 'border-black/5'
      } hover:shadow-xl hover:shadow-orange-100`}
      id={`product-${product.id}`}
    >
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
        {product.blockchainHash && (
          <div className="bg-indigo-600/90 backdrop-blur-md text-white px-3 py-1.5 rounded-xl text-[9px] font-black tracking-widest flex items-center gap-1.5 shadow-lg border border-white/20">
            <ShieldCheck size={12} className="text-orange-400" />
            <span>AUTENTICIDADE</span>
          </div>
        )}
        
        {isAiVerified && (
          <div className="bg-orange-500/90 backdrop-blur-md text-white px-3 py-1.5 rounded-xl text-[9px] font-black tracking-widest flex items-center gap-1.5 shadow-lg border border-white/20">
            <Sparkles size={12} className="text-yellow-300" />
            <span>IA VERIFICADO</span>
          </div>
        )}
        
        {product.isHot && !product.blockchainHash && !isAiVerified && (
          <div className="bg-gradient-to-r from-orange-500 to-red-600 text-white px-3 py-1.5 rounded-xl text-[10px] font-black tracking-widest flex items-center gap-1.5 shadow-lg animate-pulse">
            <Flame size={14} fill="currentColor" />
            <span>OFERTA QUENTE</span>
          </div>
        )}
      </div>
      
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-2 items-end">
        {discount > 0 && (
          <div className="bg-yellow-400 text-gray-900 px-3 py-1.5 rounded-xl text-[11px] font-black shadow-lg border-2 border-white">
            -{discount}% OFF
          </div>
        )}
        
        <div className="flex flex-col gap-2">
          <button 
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onWishlistToggle?.(product.id);
            }}
            className={`p-2.5 rounded-full shadow-lg border-2 border-white transition-all transform active:scale-90 ${isWishlisted ? 'bg-orange-500 text-white' : 'bg-white text-gray-400 hover:text-orange-500'}`}
            title={isWishlisted ? "Remover da lista" : "Adicionar à lista"}
          >
            <Heart size={18} fill={isWishlisted ? "currentColor" : "none"} />
          </button>
          
          <button 
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onShare?.(product);
            }}
            className="p-2.5 bg-white text-gray-400 hover:text-blue-500 rounded-full shadow-lg border-2 border-white transition-all transform active:scale-90"
            title="Compartilhar"
          >
            <Share2 size={18} />
          </button>
        </div>
      </div>

      <div className="aspect-square overflow-hidden bg-gray-50 flex-shrink-0">
        <img 
          src={product.imageUrl} 
          alt={product.title}
          className="w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="p-5 flex flex-col flex-grow">
        <div className="flex items-center gap-2 mb-3">
          <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
            product.platform === 'Shopee' ? 'bg-orange-100 text-orange-600' :
            product.platform === 'Mercado Livre' ? 'bg-yellow-100 text-yellow-700' :
            product.platform === 'Amazon' ? 'bg-blue-100 text-blue-600' :
            'bg-gray-100 text-gray-600'
          }`}>
            {product.platform}
          </span>
          <span className="text-[10px] text-gray-400 font-medium uppercase tracking-wider">
            {product.category}
          </span>
        </div>

        <h3 className="font-bold text-gray-900 leading-snug mb-1 line-clamp-2 min-h-[3rem] text-[15px] group-hover:text-orange-600 transition-colors">
          {product.title}
        </h3>

        <div className="flex items-center gap-1 mb-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star 
              key={i} 
              size={12} 
              className={i < Math.floor(product.rating || 5) ? "text-yellow-400 fill-yellow-400" : "text-gray-200"} 
            />
          ))}
          <span className="text-[10px] font-bold text-gray-400 ml-1">{product.rating || '5.0'}</span>
        </div>

        {product.description && (
          <p className="text-xs text-gray-500 line-clamp-2 mb-4 leading-relaxed italic">
            "{product.description}"
          </p>
        )}

        <div className="mt-auto">
          <div className="relative group/price mb-5">
            <div className="flex flex-col">
              {product.originalPrice && (
                <span className="text-xs text-gray-400 line-through font-medium">
                  De: R$ {product.originalPrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              )}
              <div className="flex items-center gap-2">
                <div className="flex items-baseline gap-1">
                  <span className="text-xs font-bold text-orange-600">R$</span>
                  <span className="text-3xl font-extrabold text-gray-950 tracking-tight">
                    {product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 }).split(',')[0]}
                    <span className="text-sm font-bold">,{product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 }).split(',')[1]}</span>
                  </span>
                </div>
                
                <button 
                  onMouseEnter={() => setShowTooltip(true)}
                  onMouseLeave={() => setShowTooltip(false)}
                  className="text-gray-300 hover:text-gray-500 transition-colors"
                >
                  <Info size={14} />
                </button>
              </div>
            </div>

            {showTooltip && (
              <div className="absolute bottom-full left-0 mb-2 w-48 bg-gray-900 text-white text-[10px] p-2 rounded-lg shadow-xl z-20 animate-in fade-in slide-in-from-bottom-1">
                <p className="font-bold mb-1">Status do Preço:</p>
                <p className="opacity-80">
                  {isAiVerified 
                    ? `Verificado por IA em ${new Date(product.lastSyncAt?.seconds * 1000).toLocaleDateString()} ${new Date(product.lastSyncAt?.seconds * 1000).toLocaleTimeString()}` 
                    : 'Aguardando verificação IA'}
                </p>
                <div className="absolute top-full left-4 border-8 border-transparent border-t-gray-900" />
              </div>
            )}
          </div>

          <a 
            href={product.affiliateLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={handleLinkClick}
            className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-4 rounded-2xl font-extrabold text-sm flex items-center justify-center gap-2 hover:from-orange-600 hover:to-orange-700 transition-all shadow-lg shadow-orange-200 group-hover:shadow-orange-300 transform active:scale-95"
          >
            <ShoppingCart size={20} />
            <span>PEGAR PROMOÇÃO</span>
            <ExternalLink size={16} className="opacity-70 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </div>
      </div>
    </motion.div>
  );
};
